﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1.Dominio
{
    class Mulher : Pessoa
    {
        public Mulher()
        {
            Genero = 'f';
        }
        public bool EstaGravida { get; set; }
        public bool EstaDeTPM { get; set; }
        public bool BebeMaisQueOsHomens { get; set; }
    }
}
